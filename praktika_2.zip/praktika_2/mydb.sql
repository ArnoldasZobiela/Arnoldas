-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 16, 2021 at 01:28 PM
-- Server version: 5.7.31
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
CREATE TABLE IF NOT EXISTS `courses` (
  `courses_ID` int(11) NOT NULL,
  `Subject_Type` varchar(45) NOT NULL,
  PRIMARY KEY (`courses_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`courses_ID`, `Subject_Type`) VALUES
(1, 'HTML'),
(2, 'C++'),
(3, 'C#'),
(4, 'JAVA'),
(5, 'PYTHON');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `groups_ID` int(11) NOT NULL,
  `Group_Type` varchar(45) NOT NULL,
  PRIMARY KEY (`groups_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`groups_ID`, `Group_Type`) VALUES
(1, 'PI20A'),
(2, 'PI20B'),
(3, 'PI20C');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `Role_ID` int(11) NOT NULL,
  `Role_Type` varchar(45) NOT NULL,
  PRIMARY KEY (`Role_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`Role_ID`, `Role_Type`) VALUES
(1, 'Administracija'),
(2, 'Destytojas'),
(3, 'Studentas');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `Users_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(45) NOT NULL,
  `Password` varchar(45) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Surname` varchar(45) NOT NULL,
  `Phone` varchar(45) NOT NULL,
  `Address` varchar(45) NOT NULL,
  `Grade` varchar(45) DEFAULT NULL,
  `Role_Role_ID` int(11) NOT NULL,
  `courses_courses_ID` int(11) NOT NULL,
  `groups_groups_ID` int(11) NOT NULL,
  PRIMARY KEY (`Users_ID`),
  KEY `fk_Users_Role1_idx` (`Role_Role_ID`),
  KEY `fk_users_courses1_idx` (`courses_courses_ID`),
  KEY `fk_users_groups1_idx` (`groups_groups_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Users_ID`, `Username`, `Password`, `Name`, `Surname`, `Phone`, `Address`, `Grade`, `Role_Role_ID`, `courses_courses_ID`, `groups_groups_ID`) VALUES
(1, 'admin', 'admin', '', '', '', '', 'NULL', 1, 0, 0),
(2, 'Destytoja', 'Destytojas', 'Destytoja', 'Destytojas', '1111111', 'vilnius', NULL, 2, 3, 3),
(3, 'Arnoldas', 'Zobiela', 'Arnoldas', 'Zobiela', '862134101', 'Sugiharos 2-37', '5', 3, 3, 3);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
