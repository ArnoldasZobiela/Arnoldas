﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Programavimo_praktika_2
{
    public partial class CreateUserForm : Form
    {
        public CreateUserForm()
        {
            InitializeComponent();
        }

        private void buttoncreateuser_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            MySqlCommand command = new MySqlCommand("INSERT INTO `users`(`Username`, `Password`, `Name`, `Surname`, `Phone`, `Address`, `Role_Role_ID`, `courses_courses_ID`, `groups_groups_ID`) VALUES (@usn, @psw, @name, @surn, @ph, @addr, @roleid, @courseid, @groupid)", db.getConnection());
        
            command.Parameters.Add("@usn", MySqlDbType.VarChar).Value = textBoxName.Text;
            command.Parameters.Add("@psw", MySqlDbType.VarChar).Value = textBoxSurname.Text;
            command.Parameters.Add("@name", MySqlDbType.VarChar).Value = textBoxName.Text;
            command.Parameters.Add("@surn", MySqlDbType.VarChar).Value = textBoxSurname.Text;
            command.Parameters.Add("@ph", MySqlDbType.VarChar).Value = textBoxPhone.Text;
            command.Parameters.Add("@addr", MySqlDbType.VarChar).Value = textBoxAddress.Text;
            command.Parameters.Add("@roleid", MySqlDbType.VarChar).Value = textBoxRoleid.Text;
            command.Parameters.Add("@courseid", MySqlDbType.VarChar).Value = textBoxCourseid.Text;
            command.Parameters.Add("@groupid", MySqlDbType.VarChar).Value = textBoxGroupid.Text;
            db.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Account created");
                this.Hide();
            }
            else
            {
                MessageBox.Show("ERROR");
            }
        }

        private void buttoncancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void buttoncourses_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            db.openConnection();
            MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM courses", db.getConnection());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            dataGridInfo.DataSource = dtbl;
        }

        private void buttongroups_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            db.openConnection();
            MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM groups", db.getConnection());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            dataGridInfo.DataSource = dtbl;
        }

        private void textBoxRoleid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
