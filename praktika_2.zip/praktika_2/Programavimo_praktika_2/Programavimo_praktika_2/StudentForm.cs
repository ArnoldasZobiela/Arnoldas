﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Programavimo_praktika_2
{
    public partial class StudentForm : Form
    {
        public StudentForm()
        {
            InitializeComponent();
        }

        private void usersdataview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        public void searchData(string valueToSearch)
        {
            MySqlCommand command;
            MySqlDataAdapter adapter;
            DataTable table;
            DB db = new DB();
            db.openConnection();
            string query = "SELECT `Name`, `Surname`, `Grade`, `courses_courses_ID` FROM `users` WHERE CONCAT(`Surname`) LIKE '%" + valueToSearch + "%'";
            command = new MySqlCommand(query, db.getConnection());
            adapter = new MySqlDataAdapter(command);
            table = new DataTable();
            adapter.Fill(table);

            usersdataview.DataSource = table;
        }
        private void buttongrades_Click(object sender, EventArgs e)
        {
            if (textBoxsurname.Text.Trim().Equals(""))
            {
                MessageBox.Show("Enter surname");
            }
            else
            {
                searchData(textBoxsurname.Text);
            }
        }

        private void buttonlogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginform = new LoginForm();
            loginform.Show();
        }

        private void buttoncourses_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            db.openConnection();
            MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM courses", db.getConnection());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            usersdataview.DataSource = dtbl;
        }

        private void textBoxsurname_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void StudentForm_Load(object sender, EventArgs e)
        {

        }
    }
}
