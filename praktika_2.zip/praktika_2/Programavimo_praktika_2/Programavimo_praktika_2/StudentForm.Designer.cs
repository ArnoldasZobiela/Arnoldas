﻿
namespace Programavimo_praktika_2
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.usersdataview = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.buttongrades = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxsurname = new System.Windows.Forms.TextBox();
            this.buttonlogout = new System.Windows.Forms.Button();
            this.buttoncourses = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.usersdataview)).BeginInit();
            this.SuspendLayout();
            // 
            // usersdataview
            // 
            this.usersdataview.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.usersdataview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.usersdataview.Location = new System.Drawing.Point(11, 201);
            this.usersdataview.Margin = new System.Windows.Forms.Padding(2);
            this.usersdataview.Name = "usersdataview";
            this.usersdataview.RowHeadersWidth = 62;
            this.usersdataview.RowTemplate.Height = 28;
            this.usersdataview.Size = new System.Drawing.Size(385, 268);
            this.usersdataview.TabIndex = 4;
            this.usersdataview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.usersdataview_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 36F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label1.Location = new System.Drawing.Point(110, 24);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 48);
            this.label1.TabIndex = 5;
            this.label1.Text = "Student";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttongrades
            // 
            this.buttongrades.BackColor = System.Drawing.SystemColors.Menu;
            this.buttongrades.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttongrades.ForeColor = System.Drawing.Color.Black;
            this.buttongrades.Location = new System.Drawing.Point(11, 147);
            this.buttongrades.Margin = new System.Windows.Forms.Padding(2);
            this.buttongrades.Name = "buttongrades";
            this.buttongrades.Size = new System.Drawing.Size(123, 26);
            this.buttongrades.TabIndex = 6;
            this.buttongrades.Text = "Check grades";
            this.buttongrades.UseVisualStyleBackColor = false;
            this.buttongrades.Click += new System.EventHandler(this.buttongrades_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(11, 99);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(210, 21);
            this.label3.TabIndex = 8;
            this.label3.Text = "Enter your Surname:";
            // 
            // textBoxsurname
            // 
            this.textBoxsurname.BackColor = System.Drawing.Color.Silver;
            this.textBoxsurname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxsurname.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold);
            this.textBoxsurname.ForeColor = System.Drawing.Color.Black;
            this.textBoxsurname.Location = new System.Drawing.Point(11, 122);
            this.textBoxsurname.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxsurname.Name = "textBoxsurname";
            this.textBoxsurname.Size = new System.Drawing.Size(210, 21);
            this.textBoxsurname.TabIndex = 10;
            this.textBoxsurname.TextChanged += new System.EventHandler(this.textBoxsurname_TextChanged);
            // 
            // buttonlogout
            // 
            this.buttonlogout.BackColor = System.Drawing.Color.DarkSlateGray;
            this.buttonlogout.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttonlogout.Location = new System.Drawing.Point(87, 492);
            this.buttonlogout.Margin = new System.Windows.Forms.Padding(2);
            this.buttonlogout.Name = "buttonlogout";
            this.buttonlogout.Size = new System.Drawing.Size(242, 40);
            this.buttonlogout.TabIndex = 12;
            this.buttonlogout.Text = "Logout";
            this.buttonlogout.UseVisualStyleBackColor = false;
            this.buttonlogout.Click += new System.EventHandler(this.buttonlogout_Click);
            // 
            // buttoncourses
            // 
            this.buttoncourses.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttoncourses.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttoncourses.ForeColor = System.Drawing.Color.Black;
            this.buttoncourses.Location = new System.Drawing.Point(299, 166);
            this.buttoncourses.Margin = new System.Windows.Forms.Padding(2);
            this.buttoncourses.Name = "buttoncourses";
            this.buttoncourses.Size = new System.Drawing.Size(97, 31);
            this.buttoncourses.TabIndex = 35;
            this.buttoncourses.Text = "Courses";
            this.buttoncourses.UseVisualStyleBackColor = false;
            this.buttoncourses.Click += new System.EventHandler(this.buttoncourses_Click);
            // 
            // StudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(407, 562);
            this.Controls.Add(this.buttoncourses);
            this.Controls.Add(this.buttonlogout);
            this.Controls.Add(this.textBoxsurname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttongrades);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.usersdataview);
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "StudentForm";
            this.Text = "StudentForm";
            this.Load += new System.EventHandler(this.StudentForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.usersdataview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView usersdataview;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttongrades;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxsurname;
        private System.Windows.Forms.Button buttonlogout;
        private System.Windows.Forms.Button buttoncourses;
    }
}