﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Programavimo_praktika_2
{
    public partial class TeacherForm : Form
    {
        public TeacherForm()
        {
            InitializeComponent();
        }
        DB db = new DB();
        private void showusers_Click(object sender, EventArgs e)
        {
            db.openConnection();
            MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT `Users_ID`, `Name`, `Surname`, `Grade`, `courses_courses_ID` FROM `users` WHERE `Role_Role_ID`=3 ", db.getConnection());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            usersdataview.DataSource = dtbl;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            db.openConnection();
            MySqlCommand command = new MySqlCommand("UPDATE `users` SET `Grade`=@gr WHERE `Users_ID`=@id", db.getConnection());
            command.Parameters.Add("@id", MySqlDbType.VarChar).Value = textBoxstudentid.Text;
            command.Parameters.Add("@gr", MySqlDbType.VarChar).Value = textBoxgrade.Text;

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Grade updated");
            }
            else
            {
                MessageBox.Show("This user doesn't exist");
            }
        }

        private void buttonlogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginform = new LoginForm();
            loginform.Show();
        }

        private void buttoncourses_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            db.openConnection();
            MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM courses", db.getConnection());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            usersdataview.DataSource = dtbl;
        }
    }
}
