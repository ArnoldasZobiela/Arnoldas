﻿
namespace Programavimo_praktika_2
{
    partial class TeacherForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.showusers = new System.Windows.Forms.Button();
            this.usersdataview = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxstudentid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxgrade = new System.Windows.Forms.TextBox();
            this.buttonlogout = new System.Windows.Forms.Button();
            this.buttoncourses = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.usersdataview)).BeginInit();
            this.SuspendLayout();
            // 
            // showusers
            // 
            this.showusers.Location = new System.Drawing.Point(38, 71);
            this.showusers.Name = "showusers";
            this.showusers.Size = new System.Drawing.Size(185, 61);
            this.showusers.TabIndex = 2;
            this.showusers.Text = "Show All Users";
            this.showusers.UseVisualStyleBackColor = true;
            this.showusers.Click += new System.EventHandler(this.showusers_Click);
            // 
            // usersdataview
            // 
            this.usersdataview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.usersdataview.Location = new System.Drawing.Point(38, 202);
            this.usersdataview.Name = "usersdataview";
            this.usersdataview.RowHeadersWidth = 62;
            this.usersdataview.RowTemplate.Height = 28;
            this.usersdataview.Size = new System.Drawing.Size(722, 236);
            this.usersdataview.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(266, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(279, 46);
            this.label1.TabIndex = 4;
            this.label1.Text = "Teacher Panel";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(621, 149);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(139, 47);
            this.button1.TabIndex = 5;
            this.button1.Text = "Add grade";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxstudentid
            // 
            this.textBoxstudentid.Location = new System.Drawing.Point(628, 78);
            this.textBoxstudentid.Name = "textBoxstudentid";
            this.textBoxstudentid.Size = new System.Drawing.Size(100, 26);
            this.textBoxstudentid.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(488, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Enter students id:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(525, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Enter grade:";
            // 
            // textBoxgrade
            // 
            this.textBoxgrade.Location = new System.Drawing.Point(628, 112);
            this.textBoxgrade.Name = "textBoxgrade";
            this.textBoxgrade.Size = new System.Drawing.Size(100, 26);
            this.textBoxgrade.TabIndex = 9;
            // 
            // buttonlogout
            // 
            this.buttonlogout.Location = new System.Drawing.Point(551, 12);
            this.buttonlogout.Name = "buttonlogout";
            this.buttonlogout.Size = new System.Drawing.Size(107, 43);
            this.buttonlogout.TabIndex = 10;
            this.buttonlogout.Text = "Logout";
            this.buttonlogout.UseVisualStyleBackColor = true;
            this.buttonlogout.Click += new System.EventHandler(this.buttonlogout_Click);
            // 
            // buttoncourses
            // 
            this.buttoncourses.Location = new System.Drawing.Point(38, 153);
            this.buttoncourses.Name = "buttoncourses";
            this.buttoncourses.Size = new System.Drawing.Size(85, 39);
            this.buttoncourses.TabIndex = 34;
            this.buttoncourses.Text = "Courses";
            this.buttoncourses.UseVisualStyleBackColor = true;
            this.buttoncourses.Click += new System.EventHandler(this.buttoncourses_Click);
            // 
            // TeacherForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttoncourses);
            this.Controls.Add(this.buttonlogout);
            this.Controls.Add(this.textBoxgrade);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxstudentid);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.usersdataview);
            this.Controls.Add(this.showusers);
            this.Name = "TeacherForm";
            this.Text = "TeacherForm";
            ((System.ComponentModel.ISupportInitialize)(this.usersdataview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button showusers;
        private System.Windows.Forms.DataGridView usersdataview;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBoxstudentid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxgrade;
        private System.Windows.Forms.Button buttonlogout;
        private System.Windows.Forms.Button buttoncourses;
    }
}