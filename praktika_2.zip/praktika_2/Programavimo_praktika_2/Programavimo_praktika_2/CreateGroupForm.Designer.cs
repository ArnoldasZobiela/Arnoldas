﻿
namespace Programavimo_praktika_2
{
    partial class CreateGroupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxgrouptype = new System.Windows.Forms.TextBox();
            this.textBoxgroupid = new System.Windows.Forms.TextBox();
            this.buttondeletegroup = new System.Windows.Forms.Button();
            this.textBoxdeletegroupid = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttoncreategroup = new System.Windows.Forms.Button();
            this.buttongroups = new System.Windows.Forms.Button();
            this.dataGridInfo = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label6.Location = new System.Drawing.Point(192, 9);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(189, 21);
            this.label6.TabIndex = 15;
            this.label6.Text = "Create New Group";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(24, 90);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(182, 16);
            this.label2.TabIndex = 41;
            this.label2.Text = "Enter new group name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 49);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 16);
            this.label1.TabIndex = 40;
            this.label1.Text = "Enter new group ID:";
            // 
            // textBoxgrouptype
            // 
            this.textBoxgrouptype.BackColor = System.Drawing.Color.Silver;
            this.textBoxgrouptype.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxgrouptype.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold);
            this.textBoxgrouptype.Location = new System.Drawing.Point(27, 113);
            this.textBoxgrouptype.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxgrouptype.Name = "textBoxgrouptype";
            this.textBoxgrouptype.Size = new System.Drawing.Size(155, 21);
            this.textBoxgrouptype.TabIndex = 39;
            // 
            // textBoxgroupid
            // 
            this.textBoxgroupid.BackColor = System.Drawing.Color.Silver;
            this.textBoxgroupid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxgroupid.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold);
            this.textBoxgroupid.Location = new System.Drawing.Point(27, 67);
            this.textBoxgroupid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxgroupid.Name = "textBoxgroupid";
            this.textBoxgroupid.Size = new System.Drawing.Size(155, 21);
            this.textBoxgroupid.TabIndex = 38;
            // 
            // buttondeletegroup
            // 
            this.buttondeletegroup.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.buttondeletegroup.Location = new System.Drawing.Point(32, 326);
            this.buttondeletegroup.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttondeletegroup.Name = "buttondeletegroup";
            this.buttondeletegroup.Size = new System.Drawing.Size(148, 23);
            this.buttondeletegroup.TabIndex = 48;
            this.buttondeletegroup.Text = "Delete Group";
            this.buttondeletegroup.UseVisualStyleBackColor = true;
            this.buttondeletegroup.Click += new System.EventHandler(this.buttondeletegroup_Click);
            // 
            // textBoxdeletegroupid
            // 
            this.textBoxdeletegroupid.BackColor = System.Drawing.Color.Silver;
            this.textBoxdeletegroupid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxdeletegroupid.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold);
            this.textBoxdeletegroupid.Location = new System.Drawing.Point(18, 299);
            this.textBoxdeletegroupid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxdeletegroupid.Name = "textBoxdeletegroupid";
            this.textBoxdeletegroupid.Size = new System.Drawing.Size(164, 21);
            this.textBoxdeletegroupid.TabIndex = 47;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(15, 281);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 16);
            this.label4.TabIndex = 46;
            this.label4.Text = "Enter group ID:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label3.Location = new System.Drawing.Point(43, 243);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 21);
            this.label3.TabIndex = 45;
            this.label3.Text = "Delete Group";
            // 
            // buttoncreategroup
            // 
            this.buttoncreategroup.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.buttoncreategroup.Location = new System.Drawing.Point(32, 157);
            this.buttoncreategroup.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttoncreategroup.Name = "buttoncreategroup";
            this.buttoncreategroup.Size = new System.Drawing.Size(150, 23);
            this.buttoncreategroup.TabIndex = 44;
            this.buttoncreategroup.Text = "Create Group";
            this.buttoncreategroup.UseVisualStyleBackColor = true;
            this.buttoncreategroup.Click += new System.EventHandler(this.buttoncreategroup_Click);
            // 
            // buttongroups
            // 
            this.buttongroups.Location = new System.Drawing.Point(551, 314);
            this.buttongroups.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttongroups.Name = "buttongroups";
            this.buttongroups.Size = new System.Drawing.Size(59, 25);
            this.buttongroups.TabIndex = 50;
            this.buttongroups.Text = "Groups";
            this.buttongroups.UseVisualStyleBackColor = true;
            this.buttongroups.Click += new System.EventHandler(this.buttongroups_Click);
            // 
            // dataGridInfo
            // 
            this.dataGridInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridInfo.Location = new System.Drawing.Point(295, 49);
            this.dataGridInfo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridInfo.Name = "dataGridInfo";
            this.dataGridInfo.RowHeadersWidth = 62;
            this.dataGridInfo.RowTemplate.Height = 28;
            this.dataGridInfo.Size = new System.Drawing.Size(324, 250);
            this.dataGridInfo.TabIndex = 49;
            // 
            // CreateGroupForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 421);
            this.Controls.Add(this.buttongroups);
            this.Controls.Add(this.dataGridInfo);
            this.Controls.Add(this.buttondeletegroup);
            this.Controls.Add(this.textBoxdeletegroupid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttoncreategroup);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxgrouptype);
            this.Controls.Add(this.textBoxgroupid);
            this.Controls.Add(this.label6);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "CreateGroupForm";
            this.Text = "CreateGroupForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxgrouptype;
        private System.Windows.Forms.TextBox textBoxgroupid;
        private System.Windows.Forms.Button buttondeletegroup;
        private System.Windows.Forms.TextBox textBoxdeletegroupid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttoncreategroup;
        private System.Windows.Forms.Button buttongroups;
        private System.Windows.Forms.DataGridView dataGridInfo;
    }
}