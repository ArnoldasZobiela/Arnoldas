﻿
namespace Programavimo_praktika_2
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.showusers = new System.Windows.Forms.Button();
            this.usersdataview = new System.Windows.Forms.DataGridView();
            this.createuser = new System.Windows.Forms.Button();
            this.buttonremoveuser = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.buttoncreategroup = new System.Windows.Forms.Button();
            this.buttonlogout = new System.Windows.Forms.Button();
            this.textBoxUserId = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.usersdataview)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label1.Location = new System.Drawing.Point(333, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 48);
            this.label1.TabIndex = 0;
            this.label1.Text = "Admin";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // showusers
            // 
            this.showusers.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showusers.Location = new System.Drawing.Point(8, 175);
            this.showusers.Margin = new System.Windows.Forms.Padding(2);
            this.showusers.Name = "showusers";
            this.showusers.Size = new System.Drawing.Size(168, 40);
            this.showusers.TabIndex = 1;
            this.showusers.Text = "Show All Users";
            this.showusers.UseVisualStyleBackColor = true;
            this.showusers.Click += new System.EventHandler(this.showusers_Click);
            // 
            // usersdataview
            // 
            this.usersdataview.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.usersdataview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.usersdataview.Location = new System.Drawing.Point(8, 233);
            this.usersdataview.Margin = new System.Windows.Forms.Padding(2);
            this.usersdataview.Name = "usersdataview";
            this.usersdataview.RowHeadersWidth = 62;
            this.usersdataview.RowTemplate.Height = 28;
            this.usersdataview.Size = new System.Drawing.Size(791, 165);
            this.usersdataview.TabIndex = 2;
            // 
            // createuser
            // 
            this.createuser.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.createuser.Location = new System.Drawing.Point(268, 87);
            this.createuser.Margin = new System.Windows.Forms.Padding(2);
            this.createuser.Name = "createuser";
            this.createuser.Size = new System.Drawing.Size(168, 40);
            this.createuser.TabIndex = 3;
            this.createuser.Text = "Create New User";
            this.createuser.UseVisualStyleBackColor = true;
            this.createuser.Click += new System.EventHandler(this.createuser_Click);
            // 
            // buttonremoveuser
            // 
            this.buttonremoveuser.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.buttonremoveuser.Location = new System.Drawing.Point(676, 175);
            this.buttonremoveuser.Margin = new System.Windows.Forms.Padding(2);
            this.buttonremoveuser.Name = "buttonremoveuser";
            this.buttonremoveuser.Size = new System.Drawing.Size(123, 40);
            this.buttonremoveuser.TabIndex = 4;
            this.buttonremoveuser.Text = "Remove User";
            this.buttonremoveuser.UseVisualStyleBackColor = true;
            this.buttonremoveuser.Click += new System.EventHandler(this.buttonremoveuser_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(626, 141);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Enter users ID you want to remove:";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(268, 130);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(168, 40);
            this.button1.TabIndex = 12;
            this.button1.Text = "Create New Course";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttoncreategroup
            // 
            this.buttoncreategroup.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.buttoncreategroup.Location = new System.Drawing.Point(268, 174);
            this.buttoncreategroup.Margin = new System.Windows.Forms.Padding(2);
            this.buttoncreategroup.Name = "buttoncreategroup";
            this.buttoncreategroup.Size = new System.Drawing.Size(168, 40);
            this.buttoncreategroup.TabIndex = 13;
            this.buttoncreategroup.Text = "Create New Group";
            this.buttoncreategroup.UseVisualStyleBackColor = true;
            this.buttoncreategroup.Click += new System.EventHandler(this.buttoncreategroup_Click);
            // 
            // buttonlogout
            // 
            this.buttonlogout.BackColor = System.Drawing.Color.DarkSlateGray;
            this.buttonlogout.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonlogout.ForeColor = System.Drawing.Color.White;
            this.buttonlogout.Location = new System.Drawing.Point(297, 415);
            this.buttonlogout.Margin = new System.Windows.Forms.Padding(2);
            this.buttonlogout.Name = "buttonlogout";
            this.buttonlogout.Size = new System.Drawing.Size(210, 46);
            this.buttonlogout.TabIndex = 14;
            this.buttonlogout.Text = "Log out";
            this.buttonlogout.UseVisualStyleBackColor = false;
            this.buttonlogout.Click += new System.EventHandler(this.buttonlogout_Click_1);
            // 
            // textBoxUserId
            // 
            this.textBoxUserId.BackColor = System.Drawing.Color.Silver;
            this.textBoxUserId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxUserId.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUserId.Location = new System.Drawing.Point(642, 156);
            this.textBoxUserId.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxUserId.Name = "textBoxUserId";
            this.textBoxUserId.Size = new System.Drawing.Size(157, 16);
            this.textBoxUserId.TabIndex = 15;
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 472);
            this.Controls.Add(this.textBoxUserId);
            this.Controls.Add(this.buttonlogout);
            this.Controls.Add(this.buttoncreategroup);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonremoveuser);
            this.Controls.Add(this.createuser);
            this.Controls.Add(this.usersdataview);
            this.Controls.Add(this.showusers);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "AdminForm";
            this.Text = "AdminForm";
            ((System.ComponentModel.ISupportInitialize)(this.usersdataview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button showusers;
        private System.Windows.Forms.DataGridView usersdataview;
        private System.Windows.Forms.Button createuser;
        private System.Windows.Forms.Button buttonremoveuser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttoncreategroup;
        private System.Windows.Forms.Button buttonlogout;
        private System.Windows.Forms.TextBox textBoxUserId;
    }
}