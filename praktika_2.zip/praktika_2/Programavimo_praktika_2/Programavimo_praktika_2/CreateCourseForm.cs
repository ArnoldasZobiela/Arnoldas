﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Programavimo_praktika_2
{
    public partial class CreateCourseForm : Form
    {
        public CreateCourseForm()
        {
            InitializeComponent();
        }

        private void buttoncourses_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            db.openConnection();
            MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM courses", db.getConnection());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            dataGridInfo.DataSource = dtbl;
        }

        private void buttoncreatecourse_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            MySqlCommand command = new MySqlCommand("INSERT INTO `courses`(`courses_ID`, `Subject_Type`) VALUES (@course, @type)", db.getConnection());

            command.Parameters.Add("@course", MySqlDbType.VarChar).Value = textBoxcourseid.Text;
            command.Parameters.Add("@type", MySqlDbType.VarChar).Value = textBoxcoursetype.Text;
            db.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Course created");
                this.Hide();
            }
            else
            {
                MessageBox.Show("ERROR");
            }
        }

        private void buttondeletecourse_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            db.openConnection();
            MySqlCommand command = new MySqlCommand("DELETE FROM `courses` WHERE `courses`.`courses_ID` = @id", db.getConnection());
            command.Parameters.Add("@id", MySqlDbType.VarChar).Value = textBoxdeletecourseid.Text;

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Course deleted");
            }
            else
            {
                MessageBox.Show("This course doesn't exist");
            }

        }
    }
}
