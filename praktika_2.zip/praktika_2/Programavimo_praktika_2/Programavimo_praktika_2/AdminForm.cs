﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Programavimo_praktika_2
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }
        DB db = new DB();
        public void showusers_Click(object sender, EventArgs e)
        {
            db.openConnection();
            MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM users", db.getConnection());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            usersdataview.DataSource = dtbl;
        }

        private void createuser_Click(object sender, EventArgs e)
        {

            //MySqlCommand command = new MySqlCommand("INSERT INTO `users`(`name`, `surname`, `birthdate`, `username`, `password`) VALUES (@nm, @sn, @date, @usn, @pass)", db.getConnection());
            CreateUserForm createuser = new CreateUserForm();
            createuser.Show();

        }
        private void buttonremoveuser_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            db.openConnection();
            MySqlCommand command = new MySqlCommand("DELETE FROM `users` WHERE `users`.`Users_ID` = @id", db.getConnection());
            command.Parameters.Add("@id", MySqlDbType.VarChar).Value = textBoxUserId.Text;
            
            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("User deleted");
            }
            else
            {
                MessageBox.Show("This user doesn't exist");
            }

        }

        private void buttonlogout_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginform = new LoginForm();
            loginform.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //this.Hide();
            CreateCourseForm courseform = new CreateCourseForm();
            courseform.Show();
        }

        private void buttoncreategroup_Click(object sender, EventArgs e)
        {
            CreateGroupForm groupform = new CreateGroupForm();
            groupform.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBoxUserId_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
