﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Programavimo_praktika_2
{
    public partial class CreateGroupForm : Form
    {
        public CreateGroupForm()
        {
            InitializeComponent();
        }

        private void buttongroups_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            db.openConnection();
            MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM groups", db.getConnection());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            dataGridInfo.DataSource = dtbl;
        }

        private void buttoncreategroup_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            MySqlCommand command = new MySqlCommand("INSERT INTO `groups`(`groups_ID`, `Group_Type`) VALUES (@group, @type)", db.getConnection());

            command.Parameters.Add("@group", MySqlDbType.VarChar).Value = textBoxgroupid.Text;
            command.Parameters.Add("@type", MySqlDbType.VarChar).Value = textBoxgrouptype.Text;
            db.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Group created");
                this.Hide();
            }
            else
            {
                MessageBox.Show("ERROR");
            }
        }

        private void buttondeletegroup_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            db.openConnection();
            MySqlCommand command = new MySqlCommand("DELETE FROM `groups` WHERE `groups`.`groups_ID` = @id", db.getConnection());
            command.Parameters.Add("@id", MySqlDbType.VarChar).Value = textBoxdeletegroupid.Text;

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Group deleted");
            }
            else
            {
                MessageBox.Show("This group doesn't exist");
            }
        }
    }
}
